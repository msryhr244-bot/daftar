import 'package:flutter/material.dart';

import 'add_product_screen.dart';
import 'db.dart';
import 'product.dart';
import 'product_details_screen.dart';
import 'theme.dart';
import 'utils.dart';
import 'widgets.dart';

class ProductsListScreen extends StatefulWidget {
  const ProductsListScreen({super.key});

  @override
  State<ProductsListScreen> createState() => _ProductsListScreenState();
}

class _ProductsListScreenState extends State<ProductsListScreen> {
  List<Product> _items = [];
  String _q = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await AppDb.products(_q);
    if (mounted) setState(() => _items = r);
  }

  Future<void> _open(Widget w) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: fabLocation,
      floatingActionButton: AddFab(() => _open(const AddProductScreen())),
      body: SafeArea(
        child: Column(
          children: [
            const Align(
                alignment: AlignmentDirectional.centerStart,
                child: ScreenHeader('مخزن المنتجات')),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SearchBox(
                  hint: 'ابحث عن منتج',
                  onChanged: (v) {
                    _q = v;
                    _load();
                  }),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: const TableHead(['المنتج', 'الكمية', 'سعر البيع']),
            ),
            Expanded(
              child: _items.isEmpty
                  ? const EmptyState('لا يوجد منتجات')
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                      itemCount: _items.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final p = _items[i];
                        return InkWell(
                          onTap: () => _open(ProductDetailsScreen(productId: p.id!)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            child: Row(
                              children: [
                                Expanded(
                                    child: Text(p.name,
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontSize: 18))),
                                Expanded(
                                    child: Text(fmt(p.qty),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: p.qty <= 0 ? AppColors.red : Colors.black))),
                                Expanded(
                                    child: Text(fmt(p.sellPrice),
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontSize: 18))),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
