import 'package:flutter/material.dart';

/// ألوان داكنة بلمسة ذهبية.
class AppColors {
  static const brand = Color(0xFFC9A227); // ذهبي
  static const onBrand = Color(0xFF1A1A1A); // لون الكتابة فوق الذهبي
  static const navy = Color(0xFF0B0B0B);
  static const red = Color(0xFFFF6B6B);
  static const field = Color(0xFF1E1E1E);
  static const panel = Color(0xFF262626);
  static const hint = Color(0xFF8A8A8A);
  static const bg = Color(0xFF121212);
}

ThemeData buildTheme() => ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.brand,
        brightness: Brightness.dark,
        primary: AppColors.brand,
        surface: AppColors.bg,
      ),
      scaffoldBackgroundColor: AppColors.bg,
      drawerTheme: const DrawerThemeData(backgroundColor: AppColors.bg),
      bottomSheetTheme: const BottomSheetThemeData(backgroundColor: AppColors.field),
    );
