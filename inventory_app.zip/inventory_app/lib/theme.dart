import 'package:flutter/material.dart';

class AppColors {
  static const brand = Color(0xFF3D6280);
  static const navy = Color(0xFF1E2D3D);
  static const red = Color(0xFFA00000);
  static const field = Color(0xFFF8F8F8);
  static const panel = Color(0xFFF0F0F0);
  static const hint = Color(0xFF9A9A9A);
}

ThemeData buildTheme() => ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: AppColors.brand),
      scaffoldBackgroundColor: Colors.white,
      dialogBackgroundColor: Colors.white,
    );
