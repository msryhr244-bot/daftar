import 'package:flutter/material.dart';

import 'theme.dart';

/// شريط العنوان: سهم الرجوع على اليمين ثم العنوان، وفي الطرف الآخر ثلاث نقاط اختيارية.
class ScreenHeader extends StatelessWidget {
  final String title;
  final Widget? trailing;
  const ScreenHeader(this.title, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          InkWell(
            onTap: () => Navigator.of(context).maybePop(),
            child: const Padding(
              padding: EdgeInsets.all(4),
              child: Icon(Icons.arrow_back, size: 34, color: Colors.white),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(title, style: const TextStyle(fontSize: 28))),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// قائمة الثلاث نقاط.
class DotsMenu extends StatelessWidget {
  final Map<String, VoidCallback> items;
  const DotsMenu(this.items, {super.key});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.more_vert, size: 30),
      onSelected: (k) => items[k]?.call(),
      itemBuilder: (_) =>
          items.keys.map((k) => PopupMenuItem(value: k, child: Text(k))).toList(),
    );
  }
}

/// خانة إدخال: حدود زرقاء وحواف دائرية.
class AppField extends StatelessWidget {
  final String? label;
  final String hint;
  final TextEditingController? controller;
  final bool center;
  final bool number;
  final double fontSize;
  final bool readOnly;
  final VoidCallback? onTap;
  final ValueChanged<String>? onChanged;
  final Widget? suffix;

  const AppField({
    super.key,
    this.label,
    required this.hint,
    this.controller,
    this.center = false,
    this.number = false,
    this.fontSize = 20,
    this.readOnly = false,
    this.onTap,
    this.onChanged,
    this.suffix,
  });

  @override
  Widget build(BuildContext context) {
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(26),
      borderSide: const BorderSide(color: AppColors.brand, width: 1.5),
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null)
          Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 4),
            child: Text(label!,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          ),
        SizedBox(
          height: 52,
          child: TextField(
            controller: controller,
            readOnly: readOnly,
            onTap: onTap,
            onChanged: onChanged,
            textAlign: center ? TextAlign.center : TextAlign.start,
            keyboardType: number
                ? const TextInputType.numberWithOptions(decimal: true)
                : TextInputType.text,
            style: TextStyle(fontSize: fontSize, color: Colors.white),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: AppColors.hint, fontSize: fontSize),
              filled: true,
              fillColor: AppColors.field,
              suffixIcon: suffix,
              contentPadding: const EdgeInsets.symmetric(horizontal: 18),
              enabledBorder: border,
              focusedBorder: border,
              border: border,
            ),
          ),
        ),
      ],
    );
  }
}

/// حقل البحث.
class SearchBox extends StatelessWidget {
  final String hint;
  final ValueChanged<String> onChanged;
  const SearchBox({super.key, required this.hint, required this.onChanged});

  @override
  Widget build(BuildContext context) => AppField(
        hint: hint,
        onChanged: onChanged,
        suffix: const Icon(Icons.search, color: AppColors.brand),
      );
}

/// زر "حفظ" الأزرق.
class SaveButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String label;
  const SaveButton({super.key, required this.onPressed, this.label = 'حفظ'});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 58,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.brand,
          foregroundColor: AppColors.onBrand,
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(29)),
        ),
        child: Text(label,
            style: const TextStyle(fontSize: 22, decoration: TextDecoration.underline)),
      ),
    );
  }
}

/// زر دائري "+" يظهر على اليمين.
class AddFab extends StatelessWidget {
  final VoidCallback onPressed;
  const AddFab(this.onPressed, {super.key});

  @override
  Widget build(BuildContext context) => FloatingActionButton(
        onPressed: onPressed,
        backgroundColor: AppColors.brand,
        foregroundColor: AppColors.onBrand,
        shape: const CircleBorder(),
        child: const Icon(Icons.add, size: 34),
      );
}

const fabLocation = FloatingActionButtonLocation.startFloat;

/// شاشة فاضية.
class EmptyState extends StatelessWidget {
  final String text;
  const EmptyState(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.inbox_outlined, size: 90, color: AppColors.hint),
            const SizedBox(height: 10),
            Text(text, style: const TextStyle(fontSize: 20, color: AppColors.hint)),
          ],
        ),
      );
}

/// رأس جدول أزرق.
class TableHead extends StatelessWidget {
  final List<String> cols;
  const TableHead(this.cols, {super.key});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: const BoxDecoration(
          color: AppColors.brand,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Row(
          children: [
            for (final c in cols)
              Expanded(
                  child: Center(
                      child: Text(c,
                          style: const TextStyle(color: AppColors.onBrand, fontSize: 14)))),
          ],
        ),
      );
}

/// اختيار من قائمة سفلية.
Future<T?> pickFromSheet<T>(
    BuildContext context, String title, List<(String, T)> items) {
  return showModalBottomSheet<T>(
    context: context,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (ctx) => SafeArea(
      child: ListView(
        shrinkWrap: true,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(title, style: const TextStyle(fontSize: 22)),
          ),
          if (items.isEmpty)
            const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: Text('لا يوجد بيانات')))
          else
            for (final it in items)
              ListTile(title: Text(it.$1), onTap: () => Navigator.pop(ctx, it.$2)),
        ],
      ),
    ),
  );
}

Future<bool> confirmDialog(BuildContext context, String title, String body) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('تأكيد', style: TextStyle(color: AppColors.red))),
      ],
    ),
  );
  return r == true;
}

/// نافذة بحقول متعددة بنفس شكل نافذة "تعديل". ترجع القيم أو null.
Future<List<String>?> askFields(
  BuildContext context,
  String title,
  List<(String, String, bool)> fields, // (label, initial, number)
) {
  final cs = [for (final f in fields) TextEditingController(text: f.$2)];
  return showDialog<List<String>>(
    context: context,
    builder: (ctx) => Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(36)),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(28, 18, 28, 26),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(title, style: const TextStyle(fontSize: 28)),
                const Spacer(),
                IconButton(
                    onPressed: () => Navigator.pop(ctx),
                    icon: const Icon(Icons.close, size: 30)),
              ],
            ),
            for (var i = 0; i < fields.length; i++)
              AppField(
                label: fields[i].$1,
                hint: fields[i].$1,
                controller: cs[i],
                number: fields[i].$3,
                center: fields[i].$3,
              ),
            const SizedBox(height: 24),
            SaveButton(onPressed: () => Navigator.pop(ctx, [for (final c in cs) c.text.trim()])),
          ],
        ),
      ),
    ),
  );
}

Future<String?> askText(BuildContext context, String title, String initial) async {
  final r = await askFields(context, title, [(title, initial, false)]);
  return r?.first;
}
