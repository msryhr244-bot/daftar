import 'package:flutter/material.dart';

import 'db.dart';
import 'invoice_screen.dart';
import 'theme.dart';
import 'utils.dart';
import 'widgets.dart';

class InvoicesListScreen extends StatefulWidget {
  final InvoiceMode mode;
  const InvoicesListScreen(this.mode, {super.key});

  @override
  State<InvoicesListScreen> createState() => _InvoicesListScreenState();
}

class _InvoicesListScreenState extends State<InvoicesListScreen> {
  List<DbRow> _rows = [];

  @override
  void initState() {
    super.initState();
    AppDb.invoices(widget.mode.type).then((r) {
      if (mounted) setState(() => _rows = r);
    });
  }

  Future<void> _show(DbRow r) async {
    final items = await AppDb.invoiceItems(r['id'] as int);
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(36)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${r['party_name'] ?? 'بدون اسم'}  •  ${r['date']}',
                  style: const TextStyle(fontSize: 20)),
              const SizedBox(height: 12),
              for (final it in items)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(children: [
                    Expanded(child: Text('${it['name']}')),
                    Text('${clean((it['qty'] as num).toDouble())} × ${fmt(it['price'] as num)}'),
                  ]),
                ),
              const Divider(),
              Text('الاجمالي: ${fmt(r['total'] as num)}',
                  style: const TextStyle(fontSize: 22, color: AppColors.red)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
                alignment: AlignmentDirectional.centerStart,
                child: ScreenHeader(widget.mode.listTitle)),
            Expanded(
              child: _rows.isEmpty
                  ? const EmptyState('لا يوجد فواتير')
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _rows.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final r = _rows[i];
                        return ListTile(
                          onTap: () => _show(r),
                          title: Text('${r['party_name'] ?? 'بدون اسم'}',
                              style: const TextStyle(fontSize: 20)),
                          subtitle: Text('${r['date']}'),
                          trailing: Text(fmt(r['total'] as num),
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
