class Product {
  final int? id;
  final String name;
  final double qty;
  final double buyPrice;
  final double sellPrice;
  final String barcode;
  final String description;
  final String category;

  const Product({
    this.id,
    required this.name,
    this.qty = 0,
    this.buyPrice = 0,
    this.sellPrice = 0,
    this.barcode = '',
    this.description = '',
    this.category = '',
  });

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'qty': qty,
        'buy_price': buyPrice,
        'sell_price': sellPrice,
        'barcode': barcode,
        'description': description,
        'category': category,
      };

  factory Product.fromMap(Map<String, Object?> m) => Product(
        id: m['id'] as int?,
        name: (m['name'] ?? '') as String,
        qty: ((m['qty'] ?? 0) as num).toDouble(),
        buyPrice: ((m['buy_price'] ?? 0) as num).toDouble(),
        sellPrice: ((m['sell_price'] ?? 0) as num).toDouble(),
        barcode: (m['barcode'] ?? '') as String,
        description: (m['description'] ?? '') as String,
        category: (m['category'] ?? '') as String,
      );

  Product copyWith({
    String? name,
    double? qty,
    double? buyPrice,
    double? sellPrice,
    String? barcode,
    String? description,
    String? category,
  }) =>
      Product(
        id: id,
        name: name ?? this.name,
        qty: qty ?? this.qty,
        buyPrice: buyPrice ?? this.buyPrice,
        sellPrice: sellPrice ?? this.sellPrice,
        barcode: barcode ?? this.barcode,
        description: description ?? this.description,
        category: category ?? this.category,
      );
}

class Party {
  final int? id;
  final String name;
  final String phone;
  final String type; // client | supplier
  const Party({this.id, required this.name, this.phone = '', required this.type});

  factory Party.fromMap(Map<String, Object?> m) => Party(
        id: m['id'] as int?,
        name: (m['name'] ?? '') as String,
        phone: (m['phone'] ?? '') as String,
        type: (m['type'] ?? 'client') as String,
      );
}

class InvoiceLine {
  final int? productId;
  final String name;
  final double qty;
  final double price;
  final double cost;
  final double sell; // سعر البيع الجديد (للمشتريات)
  const InvoiceLine({
    this.productId,
    required this.name,
    required this.qty,
    required this.price,
    this.cost = 0,
    this.sell = 0,
  });
  double get total => qty * price;
}
