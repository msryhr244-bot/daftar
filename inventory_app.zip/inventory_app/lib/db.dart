import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'product.dart';

typedef DbRow = Map<String, Object?>;

class AppDb {
  static Database? _db;
  static Future<Database> get db async => _db ??= await _open();

  static const _schema = [
    '''CREATE TABLE IF NOT EXISTS products(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, qty REAL DEFAULT 0,
      buy_price REAL DEFAULT 0, sell_price REAL DEFAULT 0,
      barcode TEXT DEFAULT '', description TEXT DEFAULT '', category TEXT DEFAULT '')''',
    '''CREATE TABLE IF NOT EXISTS parties(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT DEFAULT '', type TEXT)''',
    '''CREATE TABLE IF NOT EXISTS vouchers(
      id INTEGER PRIMARY KEY AUTOINCREMENT, party_id INTEGER, kind TEXT,
      amount REAL, note TEXT DEFAULT '', date TEXT)''',
    '''CREATE TABLE IF NOT EXISTS expenses(
      id INTEGER PRIMARY KEY AUTOINCREMENT, payee TEXT, amount REAL, date TEXT)''',
    '''CREATE TABLE IF NOT EXISTS treasury(
      id INTEGER PRIMARY KEY AUTOINCREMENT, amount REAL, note TEXT DEFAULT '', date TEXT)''',
    '''CREATE TABLE IF NOT EXISTS invoices(
      id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, party_id INTEGER,
      total REAL, date TEXT)''',
    '''CREATE TABLE IF NOT EXISTS invoice_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER, product_id INTEGER,
      name TEXT, qty REAL, price REAL, cost REAL DEFAULT 0)''',
  ];

  static Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'inventory.db');
    return openDatabase(path,
        version: 2,
        onCreate: (d, v) => _create(d),
        onUpgrade: (d, o, n) => _create(d));
  }

  static Future<void> _create(Database d) async {
    for (final s in _schema) {
      await d.execute(s);
    }
  }

  static Future<List<DbRow>> q(String sql, [List<Object?>? args]) async =>
      (await db).rawQuery(sql, args);

  static Future<double> _sum(String sql, List<Object?> args) async {
    final r = await q(sql, args);
    return ((r.first.values.first ?? 0) as num).toDouble();
  }

  // ---------- المنتجات ----------
  static Future<int> insertProduct(Product x) async =>
      (await db).insert('products', x.toMap());

  static Future<Product?> getProduct(int id) async {
    final r = await q('SELECT * FROM products WHERE id=?', [id]);
    return r.isEmpty ? null : Product.fromMap(r.first);
  }

  static Future<void> updateProduct(Product x) async => (await db)
      .update('products', x.toMap(), where: 'id=?', whereArgs: [x.id]);

  static Future<void> deleteProduct(int id) async =>
      (await db).delete('products', where: 'id=?', whereArgs: [id]);

  static Future<List<Product>> products([String search = '']) async {
    final r = search.trim().isEmpty
        ? await q('SELECT * FROM products ORDER BY name')
        : await q(
            'SELECT * FROM products WHERE name LIKE ? OR barcode LIKE ? ORDER BY name',
            ['%${search.trim()}%', '%${search.trim()}%']);
    return r.map(Product.fromMap).toList();
  }

  // ---------- العملاء والموردين ----------
  static Future<int> insertParty(Party x) async => (await db).insert(
      'parties', {'name': x.name, 'phone': x.phone, 'type': x.type});

  static Future<List<Party>> parties(String type, [String search = '']) async {
    final r = await q(
        'SELECT * FROM parties WHERE type=? AND name LIKE ? ORDER BY name',
        [type, '%${search.trim()}%']);
    return r.map(Party.fromMap).toList();
  }

  static Future<void> deleteParty(int id) async {
    final d = await db;
    await d.delete('parties', where: 'id=?', whereArgs: [id]);
    await d.delete('vouchers', where: 'party_id=?', whereArgs: [id]);
  }

  /// رصيد العميل = اللي عليه لنا، رصيد المورد = اللي علينا له.
  static Future<double> balance(Party x) async {
    final id = x.id;
    Future<double> inv(String t) =>
        _sum('SELECT SUM(total) FROM invoices WHERE type=? AND party_id=?', [t, id]);
    Future<double> vou(String k) => _sum(
        'SELECT SUM(amount) FROM vouchers WHERE kind=? AND party_id=?', [k, id]);
    if (x.type == 'client') {
      return await inv('sale') - await inv('return') - await vou('received') + await vou('paid');
    }
    return await inv('purchase') - await vou('paid') + await vou('received');
  }

  static Future<void> addVoucher(int partyId, String kind, double amount, String note) async =>
      (await db).insert('vouchers', {
        'party_id': partyId, 'kind': kind, 'amount': amount, 'note': note, 'date': _today(),
      });

  /// كل حركات الطرف (فواتير وسندات) من الأحدث للأقدم.
  static Future<List<DbRow>> partyMoves(int id) => q('''
    SELECT 'inv' AS src, id, type AS kind, total AS amount, date FROM invoices WHERE party_id=?
    UNION ALL
    SELECT 'vou' AS src, id, kind, amount, date FROM vouchers WHERE party_id=?
    ORDER BY date DESC, id DESC''', [id, id]);

  // ---------- الفواتير ----------
  static String _today() {
    final n = DateTime.now();
    return '${n.year.toString().padLeft(4, '0')}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  static Future<int> saveInvoice(String type, int? partyId, List<InvoiceLine> lines) async {
    final d = await db;
    return d.transaction((t) async {
      final total = lines.fold<double>(0, (s, l) => s + l.total);
      final id = await t.insert('invoices',
          {'type': type, 'party_id': partyId, 'total': total, 'date': _today()});
      for (final l in lines) {
        await t.insert('invoice_items', {
          'invoice_id': id, 'product_id': l.productId, 'name': l.name,
          'qty': l.qty, 'price': l.price, 'cost': l.cost,
        });
        if (l.productId == null || type == 'quote') continue;
        if (type == 'purchase') {
          await t.rawUpdate(
              'UPDATE products SET qty=qty+?, buy_price=?, sell_price=CASE WHEN ?>0 THEN ? ELSE sell_price END WHERE id=?',
              [l.qty, l.price, l.sell, l.sell, l.productId]);
        } else {
          final delta = type == 'sale' ? -l.qty : l.qty;
          await t.rawUpdate('UPDATE products SET qty=qty+? WHERE id=?', [delta, l.productId]);
        }
      }
      return id;
    });
  }

  static Future<List<DbRow>> invoices(String type) => q('''
    SELECT i.*, p.name AS party_name FROM invoices i
    LEFT JOIN parties p ON p.id=i.party_id
    WHERE i.type=? ORDER BY i.date DESC, i.id DESC''', [type]);

  static Future<List<DbRow>> invoiceItems(int id) =>
      q('SELECT * FROM invoice_items WHERE invoice_id=?', [id]);

  // ---------- المصروفات والخزينة ----------
  static Future<void> addExpense(String payee, double amount) async =>
      (await db).insert('expenses', {'payee': payee, 'amount': amount, 'date': _today()});

  static Future<List<DbRow>> expenses() =>
      q('SELECT * FROM expenses ORDER BY date DESC, id DESC');

  static Future<void> deleteExpense(int id) async =>
      (await db).delete('expenses', where: 'id=?', whereArgs: [id]);

  static Future<void> addTreasury(double amount, String note) async =>
      (await db).insert('treasury', {'amount': amount, 'note': note, 'date': _today()});

  // ---------- ملخص الحسابات ----------
  static Future<Map<String, double>> summary(String from, String to) async {
    final sales = await _sum(
        "SELECT SUM(total) FROM invoices WHERE type='sale' AND date BETWEEN ? AND ?", [from, to]);
    final purchases = await _sum(
        "SELECT SUM(total) FROM invoices WHERE type='purchase' AND date BETWEEN ? AND ?", [from, to]);
    final returns = await _sum(
        "SELECT SUM(total) FROM invoices WHERE type='return' AND date BETWEEN ? AND ?", [from, to]);
    final expenses = await _sum(
        'SELECT SUM(amount) FROM expenses WHERE date BETWEEN ? AND ?', [from, to]);
    final gross = await _sum('''
      SELECT SUM(CASE WHEN i.type='sale' THEN (it.price-it.cost)*it.qty
                      WHEN i.type='return' THEN -(it.price-it.cost)*it.qty ELSE 0 END)
      FROM invoice_items it JOIN invoices i ON i.id=it.invoice_id
      WHERE i.date BETWEEN ? AND ?''', [from, to]);
    return {
      'sales': sales, 'purchases': purchases, 'returns': returns,
      'expenses': expenses, 'profit': gross - expenses,
    };
  }

  static Future<Map<String, double>> totals() async {
    final stock = await _sum('SELECT SUM(qty*buy_price) FROM products', []);
    final dep = await _sum('SELECT SUM(amount) FROM treasury', []);
    final rec = await _sum("SELECT SUM(amount) FROM vouchers WHERE kind='received'", []);
    final paid = await _sum("SELECT SUM(amount) FROM vouchers WHERE kind='paid'", []);
    final exp = await _sum('SELECT SUM(amount) FROM expenses', []);
    double clients = 0, suppliers = 0;
    for (final c in await parties('client')) {
      clients += await balance(c);
    }
    for (final s in await parties('supplier')) {
      suppliers += await balance(s);
    }
    return {
      'stock': stock, 'treasury': dep + rec - paid - exp,
      'clients': clients, 'suppliers': suppliers,
    };
  }
}
