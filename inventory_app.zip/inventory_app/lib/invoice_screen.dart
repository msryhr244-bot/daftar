import 'package:flutter/material.dart';

import 'db.dart';
import 'invoices_list_screen.dart';
import 'product.dart';
import 'theme.dart';
import 'utils.dart';
import 'widgets.dart';

enum InvoiceMode { purchase, sale, returned, quote }

extension InvoiceModeX on InvoiceMode {
  String get type => const {
        InvoiceMode.purchase: 'purchase',
        InvoiceMode.sale: 'sale',
        InvoiceMode.returned: 'return',
        InvoiceMode.quote: 'quote',
      }[this]!;
  String get title => const {
        InvoiceMode.purchase: 'فاتورة شراء جديدة',
        InvoiceMode.sale: 'اضافة مبيعة',
        InvoiceMode.returned: 'فاتورة مرتجع جديدة',
        InvoiceMode.quote: 'عرض سعر جديد',
      }[this]!;
  String get listTitle => const {
        InvoiceMode.purchase: 'قائمة المشتريات',
        InvoiceMode.sale: 'قائمة المبيعات',
        InvoiceMode.returned: 'قائمة المرتجعات',
        InvoiceMode.quote: 'قائمة عروض الأسعار',
      }[this]!;
  bool get isSupplier => this == InvoiceMode.purchase;
}

class InvoiceScreen extends StatefulWidget {
  final InvoiceMode mode;
  const InvoiceScreen(this.mode, {super.key});

  @override
  State<InvoiceScreen> createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  final List<InvoiceLine> _lines = [];
  Party? _party;

  double get _total => _lines.fold(0, (s, l) => s + l.total);

  Future<void> _pickParty() async {
    final type = widget.mode.isSupplier ? 'supplier' : 'client';
    final list = await AppDb.parties(type);
    if (!mounted) return;
    final id = await pickFromSheet<int>(
        context,
        widget.mode.isSupplier ? 'اختر المورد' : 'اختر العميل',
        [for (final p in list) (p.name, p.id!)]);
    if (id != null) setState(() => _party = list.firstWhere((p) => p.id == id));
  }

  Future<void> _addLine() async {
    final products = await AppDb.products();
    if (!mounted) return;
    final id = await pickFromSheet<int>(
        context, 'اختر المنتج', [for (final p in products) (p.name, p.id!)]);
    if (id == null || !mounted) return;
    final p = products.firstWhere((x) => x.id == id);
    final buying = widget.mode == InvoiceMode.purchase;
    final r = await askFields(context, p.name, [
      ('الكمية', '1', true),
      (buying ? 'سعر الشراء' : 'السعر', clean(buying ? p.buyPrice : p.sellPrice), true),
      if (buying) ('سعر البيع', clean(p.sellPrice), true),
    ]);
    if (r == null) return;
    final qty = parseNum(r[0]);
    if (qty <= 0) return;
    setState(() => _lines.add(InvoiceLine(
          productId: p.id,
          name: p.name,
          qty: qty,
          price: parseNum(r[1]),
          cost: p.buyPrice,
          sell: buying ? parseNum(r[2]) : 0,
        )));
  }

  Future<void> _save() async {
    if (_lines.isEmpty) {
      toast(context, 'اضف صنف واحد على الاقل');
      return;
    }
    await AppDb.saveInvoice(widget.mode.type, _party?.id, _lines);
    if (!mounted) return;
    toast(context, 'تم الحفظ');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.mode;
    return Scaffold(
      floatingActionButtonLocation: fabLocation,
      floatingActionButton: AddFab(_addLine),
      body: SafeArea(
        child: Column(
          children: [
            ScreenHeader(m.title,
                trailing: DotsMenu({
                  m.listTitle: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => InvoicesListScreen(m))),
                })),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: AppField(
                hint: m.isSupplier ? 'اختر المورد' : 'اختر العميل',
                controller: TextEditingController(text: _party?.name ?? ''),
                readOnly: true,
                onTap: _pickParty,
                suffix: const Icon(Icons.arrow_drop_down, color: AppColors.brand),
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: const TableHead(['الصنف', 'الكمية', 'السعر', 'الاجمالي']),
            ),
            Expanded(
              child: _lines.isEmpty
                  ? const EmptyState('اضغط + لاضافة صنف')
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                      itemCount: _lines.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final l = _lines[i];
                        return Dismissible(
                          key: ObjectKey(l),
                          background: Container(color: AppColors.red),
                          onDismissed: (_) => setState(() => _lines.removeAt(i)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            child: Row(
                              children: [
                                Expanded(
                                    child: Text(l.name,
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontSize: 16))),
                                Expanded(
                                    child: Text(clean(l.qty),
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontSize: 16))),
                                Expanded(
                                    child: Text(fmt(l.price),
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontSize: 16))),
                                Expanded(
                                    child: Text(fmt(l.total),
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontSize: 16))),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              decoration: const BoxDecoration(
                color: AppColors.panel,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Text('الاجمالي', style: TextStyle(fontSize: 22)),
                      const Spacer(),
                      Text(fmt(_total),
                          style: const TextStyle(
                              fontSize: 28, fontWeight: FontWeight.w700, color: AppColors.red)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  SaveButton(onPressed: _save),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
