import 'package:flutter/material.dart';

import 'db.dart';
import 'theme.dart';
import 'utils.dart';
import 'widgets.dart';

class AccountsScreen extends StatefulWidget {
  const AccountsScreen({super.key});

  @override
  State<AccountsScreen> createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen> {
  Period _period = Period.month;
  Map<String, double> _s = {};
  Map<String, double> _t = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final (from, to) = periodRange(_period);
    final s = await AppDb.summary(from, to);
    final t = await AppDb.totals();
    if (mounted) {
      setState(() {
        _s = s;
        _t = t;
      });
    }
  }

  Widget _card(String label, String key, Map<String, double> src, {Color? color}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: AppColors.panel,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.brand, width: 1.5),
      ),
      child: Row(
        children: [
          Text(label, style: const TextStyle(fontSize: 20)),
          const Spacer(),
          Text(fmt(src[key] ?? 0),
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: color)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const Align(
                alignment: AlignmentDirectional.centerStart,
                child: ScreenHeader('ادارة الحسابات')),
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  for (final p in Period.values)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChoiceChip(
                        label: Text(periodNames[p]!),
                        selected: _period == p,
                        selectedColor: AppColors.brand,
                        labelStyle:
                            TextStyle(color: _period == p ? Colors.white : Colors.black),
                        onSelected: (_) {
                          _period = p;
                          _load();
                        },
                      ),
                    ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _card('المبيعات', 'sales', _s),
                  _card('المشتريات', 'purchases', _s),
                  _card('المرتجعات', 'returns', _s),
                  _card('المصروفات', 'expenses', _s, color: AppColors.red),
                  _card('صافي الربح', 'profit', _s, color: AppColors.brand),
                  const Divider(height: 28),
                  _card('الخزينة', 'treasury', _t),
                  _card('قيمة المخزون', 'stock', _t),
                  _card('مطلوب من العملاء', 'clients', _t),
                  _card('مطلوب للموردين', 'suppliers', _t),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
