import 'package:flutter/material.dart';

import 'db.dart';
import 'product.dart';
import 'theme.dart';
import 'utils.dart';
import 'widgets.dart';

class ProductDetailsScreen extends StatefulWidget {
  final int productId;
  const ProductDetailsScreen({super.key, required this.productId});

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  Product? _p;
  bool _more = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await AppDb.getProduct(widget.productId);
    if (mounted) setState(() => _p = p);
  }

  Future<void> _save(Product p) async {
    await AppDb.updateProduct(p);
    await _load();
  }

  Future<void> _editText(String title, String current, Product Function(String) apply) async {
    final v = await askText(context, title, current);
    if (v != null) await _save(apply(v));
  }

  Future<void> _showEdit() async {
    final p = _p!;
    final r = await askFields(context, 'تعديل', [
      ('الكمية', clean(p.qty), true),
      ('سعر الشراء', clean(p.buyPrice), true),
      ('سعر البيع', clean(p.sellPrice), true),
    ]);
    if (r != null) {
      await _save(p.copyWith(
          qty: parseNum(r[0]), buyPrice: parseNum(r[1]), sellPrice: parseNum(r[2])));
    }
  }

  Future<void> _delete() async {
    if (await confirmDialog(context, 'حذف المنتج', 'هتحذف "${_p!.name}" نهائياً. متأكد؟')) {
      await AppDb.deleteProduct(_p!.id!);
      if (mounted) Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    return Scaffold(
      body: SafeArea(
        child: p == null
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  const Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: ScreenHeader('تفاصيل المنتج')),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 14),
                          Center(child: Text(p.name, style: const TextStyle(fontSize: 32))),
                          const SizedBox(height: 14),
                          if (_more) ...[
                            Row(
                              children: [
                                const Text('الوصف:',
                                    style: TextStyle(
                                        color: AppColors.brand,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 20)),
                                const SizedBox(width: 8),
                                Expanded(
                                    child: Text(p.description,
                                        style: const TextStyle(
                                            fontSize: 20, color: Colors.white70))),
                                IconButton(
                                    onPressed: () => _editText('الوصف', p.description,
                                        (v) => p.copyWith(description: v)),
                                    icon: const Icon(Icons.edit, color: AppColors.brand)),
                              ],
                            ),
                            _LinkRow(
                                text: p.category.isEmpty
                                    ? 'اضافة تصنيف للمنتج'
                                    : 'التصنيف: ${p.category}',
                                onTap: () => _editText(
                                    'التصنيف', p.category, (v) => p.copyWith(category: v))),
                            _LinkRow(
                                text: p.barcode.isEmpty
                                    ? 'اضافة باركود للمنتج'
                                    : 'الباركود: ${p.barcode}',
                                onTap: () => _editText(
                                    'الباركود', p.barcode, (v) => p.copyWith(barcode: v))),
                          ],
                          Center(
                            child: TextButton(
                              onPressed: () => setState(() => _more = !_more),
                              child: Text(_more ? 'عرض اقل' : 'عرض المزيد',
                                  style: const TextStyle(
                                      color: AppColors.brand,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w700)),
                            ),
                          ),
                          const SizedBox(height: 8),
                          _StockTable(p: p),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    child: Row(
                      children: [
                        const Text('الكمية الاجمالية بالمخزن', style: TextStyle(fontSize: 22)),
                        const Spacer(),
                        Container(
                          width: 170,
                          height: 50,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: AppColors.panel,
                            borderRadius: BorderRadius.circular(25),
                            border: Border.all(color: AppColors.brand, width: 1.5),
                          ),
                          child: Text(fmt(p.qty),
                              style: const TextStyle(
                                  color: AppColors.red,
                                  fontSize: 28,
                                  fontWeight: FontWeight.w700)),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    color: AppColors.brand,
                    child: Row(
                      children: [
                        _BarButton(icon: Icons.edit, label: 'سعر البيع', onTap: _showEdit),
                        _BarButton(icon: Icons.add, label: 'اضف كمية', onTap: _showEdit),
                        _BarButton(icon: Icons.delete, label: 'حذف المنتج', onTap: _delete),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _LinkRow extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _LinkRow({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            const Icon(Icons.add, color: AppColors.brand, size: 26),
            const SizedBox(width: 12),
            Text(text,
                style: const TextStyle(
                    color: AppColors.brand, fontWeight: FontWeight.w700, fontSize: 21)),
          ],
        ),
      ),
    );
  }
}

class _StockTable extends StatelessWidget {
  final Product p;
  const _StockTable({required this.p});

  @override
  Widget build(BuildContext context) {
    const valStyle =
        TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: Colors.white70);
    return Column(
      children: [
        const TableHead(['رصيد المخزن', 'سعر الشراء', 'سعر البيع']),
        Container(
          color: AppColors.panel,
          padding: const EdgeInsets.only(top: 10, bottom: 28),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  children: [
                    Text(fmt(p.qty), style: valStyle.copyWith(color: AppColors.red)),
                    const Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Padding(
                        padding: EdgeInsetsDirectional.only(start: 14, top: 6),
                        child: Text('بدون فاتورة شراء',
                            style: TextStyle(fontSize: 17, color: Colors.white60)),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(child: Center(child: Text(fmt(p.buyPrice), style: valStyle))),
              Expanded(child: Center(child: Text(fmt(p.sellPrice), style: valStyle))),
            ],
          ),
        ),
      ],
    );
  }
}

class _BarButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _BarButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(
            children: [
              Icon(icon, color: AppColors.onBrand, size: 30),
              Text(label, style: const TextStyle(color: AppColors.onBrand, fontSize: 15)),
            ],
          ),
        ),
      ),
    );
  }
}
