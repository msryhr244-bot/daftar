import 'package:flutter/material.dart';

import 'db.dart';
import 'product.dart';
import 'theme.dart';
import 'utils.dart';
import 'widgets.dart';

String _word(String type) => type == 'client' ? 'عميل' : 'مورد';

class PartiesListScreen extends StatefulWidget {
  final String type; // client | supplier
  const PartiesListScreen(this.type, {super.key});

  @override
  State<PartiesListScreen> createState() => _PartiesListScreenState();
}

class _PartiesListScreenState extends State<PartiesListScreen> {
  List<(Party, double)> _items = [];
  String _q = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await AppDb.parties(widget.type, _q);
    final out = <(Party, double)>[];
    for (final p in list) {
      out.add((p, await AppDb.balance(p)));
    }
    if (mounted) setState(() => _items = out);
  }

  Future<void> _open(Widget w) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final isClient = widget.type == 'client';
    return Scaffold(
      floatingActionButtonLocation: fabLocation,
      floatingActionButton: AddFab(() => _open(AddPartyScreen(widget.type))),
      body: SafeArea(
        child: Column(
          children: [
            Align(
                alignment: AlignmentDirectional.centerStart,
                child: ScreenHeader(isClient ? 'العملاء' : 'الموردين')),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SearchBox(
                  hint: 'ابحث عن ${_word(widget.type)}',
                  onChanged: (v) {
                    _q = v;
                    _load();
                  }),
            ),
            const SizedBox(height: 14),
            Expanded(
              child: _items.isEmpty
                  ? EmptyState('لا يوجد ${isClient ? 'عملاء' : 'موردين'}')
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                      itemCount: _items.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final (p, bal) = _items[i];
                        return ListTile(
                          onTap: () => _open(PartyAccountScreen(p)),
                          leading: const CircleAvatar(
                              backgroundColor: AppColors.brand,
                              child: Icon(Icons.person, color: Colors.white)),
                          title: Text(p.name, style: const TextStyle(fontSize: 20)),
                          subtitle: p.phone.isEmpty ? null : Text(p.phone),
                          trailing: Text(fmt(bal),
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w700,
                                  color: bal > 0 ? AppColors.red : Colors.black)),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class AddPartyScreen extends StatefulWidget {
  final String type;
  const AddPartyScreen(this.type, {super.key});

  @override
  State<AddPartyScreen> createState() => _AddPartyScreenState();
}

class _AddPartyScreenState extends State<AddPartyScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      toast(context, 'ادخل الاسم');
      return;
    }
    await AppDb.insertParty(
        Party(name: _name.text.trim(), phone: _phone.text.trim(), type: widget.type));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final w = _word(widget.type);
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ScreenHeader('اضافة $w جديد'),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppField(label: 'اسم ال$w', hint: 'ادخل اسم ال$w', controller: _name),
                    AppField(
                        label: 'رقم الهاتف',
                        hint: '(اختياري)',
                        controller: _phone,
                        number: true,
                        center: true),
                    const SizedBox(height: 26),
                    SaveButton(onPressed: _save),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PartyAccountScreen extends StatefulWidget {
  final Party party;
  const PartyAccountScreen(this.party, {super.key});

  @override
  State<PartyAccountScreen> createState() => _PartyAccountScreenState();
}

class _PartyAccountScreenState extends State<PartyAccountScreen> {
  double _bal = 0;
  List<DbRow> _moves = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final b = await AppDb.balance(widget.party);
    final m = await AppDb.partyMoves(widget.party.id!);
    if (mounted) {
      setState(() {
        _bal = b;
        _moves = m;
      });
    }
  }

  Future<void> _voucher(String kind) async {
    final r = await askFields(
        context, kind == 'received' ? 'استلام مبلغ' : 'دفع مبلغ',
        [('المبلغ', '', true), ('ملاحظة', '', false)]);
    if (r == null) return;
    final amount = parseNum(r[0]);
    if (amount <= 0) return;
    await AppDb.addVoucher(widget.party.id!, kind, amount, r[1]);
    _load();
  }

  Future<void> _delete() async {
    if (await confirmDialog(
        context, 'حذف', 'هتحذف "${widget.party.name}" وكل سنداته. متأكد؟')) {
      await AppDb.deleteParty(widget.party.id!);
      if (mounted) Navigator.of(context).pop();
    }
  }

  String _label(DbRow m) {
    if (m['src'] == 'vou') {
      return m['kind'] == 'received' ? 'سند استلام' : 'سند دفع';
    }
    return const {
          'sale': 'فاتورة بيع',
          'purchase': 'فاتورة شراء',
          'return': 'فاتورة مرتجع',
          'quote': 'عرض سعر',
        }[m['kind']] ??
        '';
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.party;
    final isClient = p.type == 'client';
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            ScreenHeader('كشف الحساب', trailing: DotsMenu({'حذف ${_word(p.type)}': _delete})),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Text(p.name, style: const TextStyle(fontSize: 30)),
                  if (p.phone.isNotEmpty) Text(p.phone, style: const TextStyle(fontSize: 18)),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.panel,
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(color: AppColors.brand, width: 1.5),
                    ),
                    child: Column(
                      children: [
                        Text(isClient ? 'المطلوب من العميل' : 'المطلوب للمورد',
                            style: const TextStyle(fontSize: 16)),
                        Text(fmt(_bal),
                            style: const TextStyle(
                                fontSize: 34, fontWeight: FontWeight.w700, color: AppColors.red)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: _moves.isEmpty
                  ? const EmptyState('لا يوجد حركات')
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _moves.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final m = _moves[i];
                        return ListTile(
                          title: Text(_label(m), style: const TextStyle(fontSize: 18)),
                          subtitle: Text('${m['date']}'),
                          trailing: Text(fmt(m['amount'] as num),
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                        );
                      },
                    ),
            ),
            Container(
              color: AppColors.brand,
              child: Row(
                children: [
                  _Bar(Icons.arrow_downward, 'استلام مبلغ', () => _voucher('received')),
                  _Bar(Icons.arrow_upward, 'دفع مبلغ', () => _voucher('paid')),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Bar extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Bar(this.icon, this.label, this.onTap);

  @override
  Widget build(BuildContext context) => Expanded(
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Column(children: [
              Icon(icon, color: Colors.white, size: 30),
              Text(label, style: const TextStyle(color: Colors.white, fontSize: 15)),
            ]),
          ),
        ),
      );
}
