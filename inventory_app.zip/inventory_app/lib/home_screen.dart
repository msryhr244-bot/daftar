import 'package:flutter/material.dart';

import 'accounts_screen.dart';
import 'add_product_screen.dart';
import 'db.dart';
import 'expense_screens.dart';
import 'invoice_screen.dart';
import 'party_screens.dart';
import 'product.dart';
import 'product_details_screen.dart';
import 'products_list_screen.dart';
import 'theme.dart';
import 'treasury_screen.dart';
import 'utils.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _scaffold = GlobalKey<ScaffoldState>();
  String _q = '';
  List<Product> _found = [];

  void _go(Widget w) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));
  }

  Future<void> _search(String v) async {
    _q = v;
    final r = v.trim().isEmpty ? <Product>[] : await AppDb.products(v);
    if (mounted) setState(() => _found = r);
  }

  Widget _card(String img, Widget screen, {double ratio = 498 / 421}) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: AspectRatio(
          aspectRatio: ratio,
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => _go(screen),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset('assets/cards/$img.png', fit: BoxFit.cover),
            ),
          ),
        ),
      ),
    );
  }

  Widget _shortcut(IconData icon, String label, Widget screen) {
    return ListTile(
      leading: Icon(icon, color: AppColors.brand, size: 28),
      title: Text(label, style: const TextStyle(fontSize: 19)),
      onTap: () {
        Navigator.of(context).pop();
        _go(screen);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffold,
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            children: [
              Container(
                height: 90,
                alignment: AlignmentDirectional.centerStart,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                color: AppColors.navy,
                child: const Text('الاختصارات',
                    style: TextStyle(color: Colors.white, fontSize: 26)),
              ),
              _shortcut(Icons.add_box, 'اضافة منتج جديد', const AddProductScreen()),
              _shortcut(Icons.person_add, 'اضافة عميل جديد', const AddPartyScreen('client')),
              _shortcut(Icons.local_shipping, 'اضافة مورد جديد', const AddPartyScreen('supplier')),
              _shortcut(Icons.receipt_long, 'اضافة مصروف جديد', const AddExpenseScreen()),
              _shortcut(Icons.savings, 'اضافة مبلغ للخزينة', const AddTreasuryScreen()),
              _shortcut(Icons.request_quote, 'عرض سعر جديد', const InvoiceScreen(InvoiceMode.quote)),
              _shortcut(Icons.assignment_return, 'فاتورة مرتجع جديدة',
                  const InvoiceScreen(InvoiceMode.returned)),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: AppColors.navy,
              padding: const EdgeInsets.fromLTRB(8, 10, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => _scaffold.currentState?.openDrawer(),
                    icon: const Icon(Icons.menu, color: Colors.white, size: 32),
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: SearchBox(hint: 'ابحث عن منتج', onChanged: _search),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _q.trim().isNotEmpty
                  ? (_found.isEmpty
                      ? const EmptyState('لا يوجد نتائج')
                      : ListView.separated(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: _found.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (_, i) {
                            final p = _found[i];
                            return ListTile(
                              title: Text(p.name, style: const TextStyle(fontSize: 20)),
                              subtitle: Text('الكمية: ${fmt(p.qty)}'),
                              trailing: Text(fmt(p.sellPrice),
                                  style: const TextStyle(
                                      fontSize: 20, fontWeight: FontWeight.w700)),
                              onTap: () => _go(ProductDetailsScreen(productId: p.id!)),
                            );
                          },
                        ))
                  : ListView(
                      padding: const EdgeInsets.all(10),
                      children: [
                        Row(children: [
                          _card('products', const ProductsListScreen(), ratio: 1018 / 406),
                        ]),
                        Row(children: [
                          _card('purchases', const InvoiceScreen(InvoiceMode.purchase)),
                          _card('sales', const InvoiceScreen(InvoiceMode.sale)),
                        ]),
                        Row(children: [
                          _card('suppliers', const PartiesListScreen('supplier')),
                          _card('clients', const PartiesListScreen('client')),
                        ]),
                        Row(children: [
                          _card('expenses', const AddExpenseScreen()),
                          _card('accounts', const AccountsScreen()),
                        ]),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
