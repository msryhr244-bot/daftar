import 'package:flutter/material.dart';

import 'db.dart';
import 'theme.dart';
import 'utils.dart';
import 'widgets.dart';

class AddExpenseScreen extends StatefulWidget {
  const AddExpenseScreen({super.key});

  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  final _payee = TextEditingController();
  final _amount = TextEditingController();

  @override
  void dispose() {
    _payee.dispose();
    _amount.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final a = parseNum(_amount.text);
    if (a <= 0) {
      toast(context, 'ادخل المبلغ');
      return;
    }
    await AppDb.addExpense(_payee.text.trim(), a);
    if (!mounted) return;
    toast(context, 'تم الحفظ');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ScreenHeader('اضافة مصروف جديد',
                  trailing: DotsMenu({
                    'قائمة المصروفات': () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const ExpensesListScreen())),
                  })),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppField(label: 'الى', hint: 'اسم المصروف او المستلم', controller: _payee),
                    AppField(
                        label: 'المبلغ',
                        hint: 'المبلغ',
                        controller: _amount,
                        number: true,
                        center: true),
                    const SizedBox(height: 26),
                    SaveButton(onPressed: _save),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ExpensesListScreen extends StatefulWidget {
  const ExpensesListScreen({super.key});

  @override
  State<ExpensesListScreen> createState() => _ExpensesListScreenState();
}

class _ExpensesListScreenState extends State<ExpensesListScreen> {
  List<DbRow> _rows = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await AppDb.expenses();
    if (mounted) setState(() => _rows = r);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: fabLocation,
      floatingActionButton: AddFab(() async {
        await Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => const AddExpenseScreen()));
        _load();
      }),
      body: SafeArea(
        child: Column(
          children: [
            const Align(
                alignment: AlignmentDirectional.centerStart, child: ScreenHeader('المصروفات')),
            Expanded(
              child: _rows.isEmpty
                  ? const EmptyState('لا يوجد مصروفات')
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                      itemCount: _rows.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final r = _rows[i];
                        return ListTile(
                          title: Text(('${r['payee'] ?? ''}').isEmpty ? 'مصروف' : '${r['payee']}',
                              style: const TextStyle(fontSize: 20)),
                          subtitle: Text('${r['date']}'),
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            Text(fmt(r['amount'] as num),
                                style: const TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.red)),
                            IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () async {
                                  if (await confirmDialog(context, 'حذف', 'حذف المصروف؟')) {
                                    await AppDb.deleteExpense(r['id'] as int);
                                    _load();
                                  }
                                }),
                          ]),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
