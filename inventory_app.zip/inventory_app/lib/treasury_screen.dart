import 'package:flutter/material.dart';

import 'db.dart';
import 'utils.dart';
import 'widgets.dart';

class AddTreasuryScreen extends StatefulWidget {
  const AddTreasuryScreen({super.key});

  @override
  State<AddTreasuryScreen> createState() => _AddTreasuryScreenState();
}

class _AddTreasuryScreenState extends State<AddTreasuryScreen> {
  final _amount = TextEditingController();
  final _note = TextEditingController();

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final a = parseNum(_amount.text);
    if (a == 0) {
      toast(context, 'ادخل المبلغ');
      return;
    }
    await AppDb.addTreasury(a, _note.text.trim());
    if (!mounted) return;
    toast(context, 'تم الحفظ');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const ScreenHeader('اضافة مبلغ للخزينة'),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppField(
                        label: 'المبلغ',
                        hint: 'المبلغ',
                        controller: _amount,
                        number: true,
                        center: true),
                    AppField(label: 'ملاحظة', hint: '(اختياري)', controller: _note),
                    const SizedBox(height: 26),
                    SaveButton(onPressed: _save),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
