import 'package:flutter/material.dart';

import 'db.dart';
import 'product.dart';
import 'product_details_screen.dart';
import 'theme.dart';
import 'utils.dart';
import 'widgets.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _name = TextEditingController();
  final _qty = TextEditingController();
  final _buy = TextEditingController();
  final _sell = TextEditingController();
  final _desc = TextEditingController();
  final _cat = TextEditingController();
  String _barcode = '';

  @override
  void dispose() {
    for (final c in [_name, _qty, _buy, _sell, _desc, _cat]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickBarcode() async {
    final v = await askText(context, 'الباركود', _barcode);
    if (v != null) setState(() => _barcode = v);
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      toast(context, 'ادخل اسم المنتج');
      return;
    }
    final id = await AppDb.insertProduct(Product(
      name: _name.text.trim(),
      qty: parseNum(_qty.text),
      buyPrice: parseNum(_buy.text),
      sellPrice: parseNum(_sell.text),
      barcode: _barcode,
      description: _desc.text.trim(),
      category: _cat.text.trim(),
    ));
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => ProductDetailsScreen(productId: id)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const ScreenHeader('اضافة منتج جديد'),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppField(label: 'اسم المنتج', hint: 'ادخل اسم منتج جديد', controller: _name),
                    AppField(
                        label: 'الكمية', hint: 'الكمية', controller: _qty, center: true, number: true),
                    Row(
                      children: [
                        Expanded(
                          child: AppField(
                              label: 'سعر الشراء',
                              hint: 'سعر الشراء',
                              controller: _buy,
                              center: true,
                              number: true),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: AppField(
                              label: 'سعر البيع',
                              hint: 'سعر البيع',
                              controller: _sell,
                              center: true,
                              number: true),
                        ),
                      ],
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 14, bottom: 4),
                      child: Text('الباركود',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                    ),
                    SizedBox(
                      width: double.infinity,
                      height: 58,
                      child: OutlinedButton(
                        onPressed: _pickBarcode,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: AppColors.brand, width: 1.5),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(29)),
                        ),
                        child: Text(_barcode.isEmpty ? 'اضافة باركود للمنتج' : _barcode,
                            style: const TextStyle(fontSize: 20)),
                      ),
                    ),
                    AppField(label: 'الوصف', hint: '(اختياري)', controller: _desc),
                    AppField(label: 'التصنيف', hint: '(اختياري)', controller: _cat),
                    const SizedBox(height: 26),
                    SaveButton(onPressed: _save),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
