import 'package:flutter/material.dart';

double parseNum(String s) =>
    double.tryParse(s.trim().replaceAll(',', '.')) ?? 0;

String fmt(num v) => v.toStringAsFixed(2);

String clean(double v) =>
    v == v.roundToDouble() ? v.toInt().toString() : v.toString();

String dateStr(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

String today() => dateStr(DateTime.now());

enum Period { today, yesterday, month, lastMonth, year, lastYear, all }

const periodNames = {
  Period.today: 'اليوم',
  Period.yesterday: 'امس',
  Period.month: 'هذا الشهر',
  Period.lastMonth: 'الشهر الماضي',
  Period.year: 'هذه السنة',
  Period.lastYear: 'السنة الماضية',
  Period.all: 'الكل',
};

/// يرجع (من، الى) كنص yyyy-MM-dd.
(String, String) periodRange(Period p) {
  final n = DateTime.now();
  switch (p) {
    case Period.today:
      return (dateStr(n), dateStr(n));
    case Period.yesterday:
      final y = n.subtract(const Duration(days: 1));
      return (dateStr(y), dateStr(y));
    case Period.month:
      return (dateStr(DateTime(n.year, n.month, 1)),
          dateStr(DateTime(n.year, n.month + 1, 0)));
    case Period.lastMonth:
      return (dateStr(DateTime(n.year, n.month - 1, 1)),
          dateStr(DateTime(n.year, n.month, 0)));
    case Period.year:
      return ('${n.year}-01-01', '${n.year}-12-31');
    case Period.lastYear:
      return ('${n.year - 1}-01-01', '${n.year - 1}-12-31');
    case Period.all:
      return ('0000-01-01', '9999-12-31');
  }
}

void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
