# تطبيق المخزون (Flutter)

## تشغيل المشروع
1. نزّل Flutter: https://docs.flutter.dev/get-started/install
2. `flutter create --platforms=android,ios inventory_app`
3. انسخ فوق المشروع الجديد: مجلد `lib` و`assets` وملف `pubspec.yaml` (استبدل الموجود).
4. جوه المجلد: `flutter pub get` ثم `flutter run`

على الموبايل: فعّل "خيارات المطور" و"تصحيح USB" ووصّله بالكابل.

## بناء APK على GitHub (من غير ما تنزل Flutter)
1. اعمل ريبو جديد على GitHub وارفع محتوى المجلد ده كله (بما فيه `.github`).
2. افتح تبويب Actions ← "Build APK" ← Run workflow (أو يشتغل تلقائي مع كل رفع).
3. بعد ما يخلص (5-10 دقايق) نزّل `app-release` من الـ Artifacts، فك الضغط وثبّت الـ APK على موبايلك.
