# تطبيق المخزون (Flutter)

## تشغيل المشروع
1. نزّل Flutter: https://docs.flutter.dev/get-started/install
2. `flutter create --platforms=android,ios inventory_app`
3. انسخ فوق المشروع الجديد: مجلد `lib` و`assets` وملف `pubspec.yaml` (استبدل الموجود).
4. جوه المجلد: `flutter pub get` ثم `flutter run`

على الموبايل: فعّل "خيارات المطور" و"تصحيح USB" ووصّله بالكابل.
